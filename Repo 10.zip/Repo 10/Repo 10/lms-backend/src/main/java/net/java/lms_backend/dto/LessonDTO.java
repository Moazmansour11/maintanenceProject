package net.java.lms_backend.dto;


public class LessonDTO {
    private String title;

    private String content;

    public String getTitle() {
        return title;
    }

    public String getContent() {
        return content;
    }

}