package net.java.lms_backend.dto;

public class FeedbackDTO {
}
